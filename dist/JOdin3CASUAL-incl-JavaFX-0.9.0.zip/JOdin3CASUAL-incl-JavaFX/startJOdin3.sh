#!/bin/zsh
java -Xmx8096m --module-path ./javafx-sdk-15.0.1/lib --add-modules javafx.controls,javafx.fxml -jar JOdin3CASUAL-0.9.0.jar
